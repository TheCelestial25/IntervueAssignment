Setup:
1. Install node 20
2. Run `npm install` from folder of this repo
3. Run `npm start`. The server will run at Port:4000