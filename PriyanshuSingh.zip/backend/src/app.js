import express from 'express';
import cors from 'cors';
import { createServer } from 'http';
import { Server } from 'socket.io';

const app = express();
const PORT = 4000;

const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

app.use(express.json());
app.use(cors());

let currentPoll = {};

app.post('/create-poll', (req, res) => {
  const { question, options } = req.body;

  if (!question || !options || options.length === 0) {
    return res.status(400).json({ error: 'Invalid poll data' });
  }

  currentPoll.question = question;
  currentPoll.startedAt = new Date();
  currentPoll.takenBy = 0;

  let results = [];

  options.map((option) => {
    let result = {};
    result.count = 0;
    result.option = option;
    results.push(result);
  });

  currentPoll.results = results;

  io.emit('new-poll', currentPoll);

  console.log('Poll received and broadcast:', currentPoll);

  res.status(200).json({ message: 'Poll created successfully', poll: currentPoll });
});

app.post('/submit-answer', (req, res) => {
  const { answer } = req.body;
  console.log(answer);

  if (!answer) {
    return res.status(400).json({ error: 'Invalid poll data' });
  }

  currentPoll.takenBy = currentPoll.takenBy + 1;

  currentPoll.results.map((optionData) => {
    if(optionData.option === answer) {
      optionData.count = optionData.count + 1;
    }
  });

  io.emit('new-poll', currentPoll);

  console.log('Poll received and broadcast:', currentPoll);

  res.status(200).json({ message: 'Poll created successfully', poll: currentPoll });
});


app.get('/get-poll', (req, res) => {
  res.status(200).json({ message: 'Poll sent successfully', poll: currentPoll });
});


io.on('connection', (socket) => {
  console.log('A user connected:', socket.id);

  socket.emit('new-poll', currentPoll);

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});


httpServer.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
