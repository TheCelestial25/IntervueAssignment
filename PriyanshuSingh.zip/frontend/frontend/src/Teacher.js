import React, { useState, useEffect } from 'react';
import LivePoll from './LivePoll';
import CreatePoll from './CreatePoll';
import socket from './socket';

const Teacher = () => {
  const [pollRunning, setPollRunning] = useState(false);
  const [poll, setPoll] = useState(null);

  useEffect(() => {
    socket.on('new-poll', (pollData) => {
      console.log(pollData);
      if (pollData) {
        setPoll(pollData);
      }
    });
    return () => {
      socket.off('new-poll');
    };
  }, []);

  return (
    <div style={{ textAlign: 'center', padding: '20px' }}>
      {
        pollRunning && Object.keys(poll).length ? (
          <>
            <LivePoll poll={poll} />
            <div style={{ marginTop: '20px' }}>
              <button
                onClick={() => setPollRunning(false)}
                style={{
                  padding: '10px 20px',
                  fontSize: '16px',
                  color: '#fff',
                  backgroundColor: '#7765DA',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  outline: 'none'
                }}
              >
                Create new
              </button>
            </div>
          </>
        ) : (
          <CreatePoll setPollRunning={setPollRunning} />
        )
      }
    </div>
  );
};

export default Teacher;
