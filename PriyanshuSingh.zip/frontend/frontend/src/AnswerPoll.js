import React, { useState } from 'react';
import axios from 'axios';

const AnswerPoll = ({ poll, setAnswered }) => {
  const [selectedOption, setSelectedOption] = useState('');

  const handleOptionChange = (e) => {
    setSelectedOption(e.target.value);
  };

  const handleSubmit = async () => {
    const pollData = {
        answer:selectedOption
      };
    try {
        console.log(selectedOption);
        const response = await axios.post('http://localhost:4000/submit-answer', pollData);
        console.log('Poll answered successfully:', response.data);
        setAnswered(true);
      } catch (error) {
        console.error('Error answering poll:', error);
      }
  };

  return (
    <div>
      <h3>{poll.question}</h3>
      {poll.results.map((obj, index) => (
        <div key={obj.option}>
          <label>
            <input
              type="radio"
              name="poll-option"
              value={obj.option}
              onChange={handleOptionChange}
              checked={selectedOption === obj.option}
            />
            {obj.option}
          </label>
        </div>
      ))}
      <button onClick={handleSubmit} disabled={!selectedOption}>
        Submit Answer
      </button>
    </div>
  );
};

export default AnswerPoll;
