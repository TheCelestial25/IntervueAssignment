import React, { useState, useEffect } from 'react';
import LivePoll from './LivePoll';
import socket from './socket';
import axios from 'axios';
import AnswerPoll from './AnswerPoll';

const Student = () => {
  const [loggedIn, setLoggedIn] = useState(false);
  const [name, setName] = useState('');
  const [poll, setPoll] = useState(null);
  const [answered, setAnswered] = useState(false);

  useEffect(() => {
    
    const storedName = sessionStorage.getItem('studentName');
    if (storedName) {
      setName(storedName);
      setLoggedIn(true);
      
      socket.emit('student-join', storedName);
    }

    
    const storedPoll = sessionStorage.getItem('pollData');
    if (storedPoll) {
      setPoll(JSON.parse(storedPoll));
    }

    
    socket.on('new-poll', (pollData) => {
      console.log(pollData);
      if (pollData) {
        setAnswered(false);
        setPoll(pollData);
        sessionStorage.setItem('pollData', JSON.stringify(pollData));
      }
    });

    
    return () => {
      socket.off('new-poll');
    };
  }, []);

  useEffect(() => {
    
    const fetchPoll = async () => {
      try {
        const response = await axios.get('http://localhost:4000/get-poll');
        const pollData = response.data.poll;
        setPoll(pollData);
        sessionStorage.setItem('pollData', JSON.stringify(pollData));
      } catch (error) {
        console.error('Error receiving poll:', error);
      }
    };

    fetchPoll();
  }, []);

  const handleLogin = () => {
    if (name.trim()) {
      sessionStorage.setItem('studentName', name);
      setLoggedIn(true);
      socket.emit('student-join', name);
    }
  };

  return (
    <>
      {!loggedIn ? (
        <div>
          <p>Enter your name:</p>
          <input value={name} onChange={(e) => setName(e.target.value)} />
          <button onClick={handleLogin}>Submit</button>
        </div>
      ) : Object.keys(poll).length ? (
        !answered ? (
          <AnswerPoll poll={poll} setAnswered={setAnswered} />
        ) : (
          <LivePoll poll={poll} />
        )
      ) : (
        <p>No live polls at the moment!</p>
      )}
    </>
  );
};

export default Student;
