import React, {useState} from 'react';
import Teacher from './Teacher';
import Student from './Student';

const App = () => {
  const [role, setRole] = useState(sessionStorage.getItem('role') || '');

  return (
    <div>
      {!role ? (
        <>
          <button style={{
                  padding: '10px 20px',
                  fontSize: '16px',
                  color: '#fff',
                  backgroundColor: '#7765DA',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  outline: 'none',
                  width: "40%",
                  marginLeft: "5%",
                  marginTop: "5%",
                  height: "50%"
                }} onClick={() => {setRole('Teacher'); sessionStorage.setItem('role', 'Teacher')}}>I'm a Teacher</button>
          <button style={{
                  padding: '10px 20px',
                  fontSize: '16px',
                  color: '#fff',
                  backgroundColor: '#5767D0',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  outline: 'none',
                  width: "40%",
                  marginLeft: "10px",
                  marginRight: "5%",
                  marginTop: "5%",
                  height: "50%"
                }} onClick={() => {setRole('Student'); sessionStorage.setItem('role', 'Student')}}>I'm a Student</button>
        </>
      ) : role === 'Teacher' ? (
        <Teacher />
      ) : (
        <Student />
      )}
    </div>
  );
};

export default App;
