import React from 'react';
import './PollResult.css';

const LivePoll = ({poll}) => {
  const totalVotes = poll.takenBy;

  return (
    <div className="poll-container">
      <h2 className="poll-question">{poll.question}</h2>
      <div className="poll-options">
        {poll.results.map((optionData, index) => {
          const votePercentage = optionData.count === 0 ? 0 : ((optionData.count / totalVotes) * 100).toFixed(1);

          return (
            <div key={index} className={`poll-option ${optionData.isCorrect ? 'correct' : ''}`}>
              <span className="option-text">{optionData.option}</span>
              <div className="vote-bar">
                <div className="vote-fill" style={{ width: `${votePercentage}%` }}></div>
              </div>
              <span className="vote-count">{votePercentage}% ({optionData.count} votes)</span>
            </div>
          );
        })}
      </div>
      <p className="total-votes">Total Votes: {totalVotes}</p>
    </div>
  );
};

export default LivePoll;
