import React, { useState } from 'react';
import axios from 'axios';

const Option = ({ optionText }) => {
    return <p>{optionText}</p>;
};

const CreatePoll = ({setPollRunning}) => {
    const [question, setQuestion] = useState("");
    const [options, setOptions] = useState([]);
  const [newOption, setNewOption] = useState('');

  const handleAddOption = () => {
    if (newOption.trim() !== '') {
      setOptions([...options, newOption]);
      setNewOption('');
    }
  };

  // Function to handle input changes
  const handleOptionChange = (e, index) => {
    const updatedOptions = [...options];
    updatedOptions[index] = e.target.value;
    setOptions(updatedOptions);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const pollData = {
      question,
      options,
    };

    try {
        const response = await axios.post('http://localhost:4000/create-poll', pollData);
        console.log('Poll created successfully:', response.data);
        setPollRunning(true);
      } catch (error) {
        console.error('Error creating poll:', error);
      }
  }

  return (
    <>
    <div>
        <p>Question: </p>
        <input
            type="text"
            placeholder={`Question`}
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
          />
    </div>
    <div>
      <h2>Create Poll Options</h2>

      {options.map((option, index) => (
        <div key={index}>
          <input
            type="text"
            placeholder={`Option ${index + 1}`}
            value={option}
            onChange={(e) => handleOptionChange(e, index)}
          />
        </div>
      ))}

      <div>
        <input
          type="text"
          placeholder="Enter new option"
          value={newOption}
          onChange={(e) => setNewOption(e.target.value)}
        />
        <button onClick={handleAddOption}>Add Option</button>
      </div>

      <button onClick={handleSubmit}>Submit Poll</button>
    </div>
    </>
  )
};

export default CreatePoll;
